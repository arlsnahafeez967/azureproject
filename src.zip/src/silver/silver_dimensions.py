# Databricks notebook source
# MAGIC %md
# MAGIC ### **DimUser**

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import os
import sys
project_path=os.path.join(os.getcwd(),'..','..')
sys.path.append(project_path)
from utils.transformation import reusable




# COMMAND ----------

# MAGIC %sql
# MAGIC GRANT USE CATALOG ON CATALOG spotifycata 
# MAGIC TO `arslanhafeez25122000_gmail.com#ext#@arslanhafeez25122000gmail.onmicrosoft.com`;
# MAGIC
# MAGIC GRANT USE SCHEMA ON SCHEMA spotifycata.silver 
# MAGIC TO `arslanhafeez25122000_gmail.com#ext#@arslanhafeez25122000gmail.onmicrosoft.com`;
# MAGIC
# MAGIC GRANT CREATE, MODIFY, SELECT ON SCHEMA spotifycata.silver 
# MAGIC TO `arslanhafeez25122000_gmail.com#ext#@arslanhafeez25122000gmail.onmicrosoft.com`;
# MAGIC

# COMMAND ----------

df_user=spark.readStream.format("cloudfiles")\
    .option("cloudfiles.format","parquet")\
    .option("cloudfiles.schemaLocation","abfss://silver@arslanstoragazure.dfs.core.windows.net/DimUser/ Checkpoints")\
    .option("schemaEvolutionMode","rescue")\
    .load("abfss://bronze@arslanstoragazure.dfs.core.windows.net/DimUser")

# COMMAND ----------

display(df_user)

# COMMAND ----------

 df_user=df_user.withColumn("user_name", upper(col("user_name")))


# COMMAND ----------

display(df_user)

# COMMAND ----------

print(df_user.columns)


# COMMAND ----------

from utils.transformation import reusable
df_user_obj=reusable()

df_user=df_user_obj.dropColumns(df_user,['_rescued_data'])
df_user=df_user.dropDuplicates(['user_name'])
display(df_user)

# COMMAND ----------

df_user.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation","abfss://silver@arslanstoragazure.dfs.core.windows.net/DimUser/ Checkpoints")\
    .trigger(once=True)\
    .option("path", "abfss://silver@arslanstoragazure.dfs.core.windows.net/DimUser/data")\
    .toTable("spotifycata.silver.DimUser")

# COMMAND ----------

# MAGIC %md
# MAGIC ### **DimArtist**

# COMMAND ----------

df_art=spark.readStream.format("cloudfiles")\
    .option("cloudfiles.format","parquet")\
    .option("cloudfiles.schemaLocation","abfss://silver@arslanstoragazure.dfs.core.windows.net/DimArtist/ Checkpoints")\
    .option("schemaEvolutionMode","rescue")\
    .load("abfss://bronze@arslanstoragazure.dfs.core.windows.net/DimArtist")

# COMMAND ----------

display(df_art)

# COMMAND ----------

df_art_obj=reusable()

df_art=df_art_obj.dropColumns(df_art,['_rescued_data'])
df_art=df_art.dropDuplicates(['artist_name'])
display(df_art)

# COMMAND ----------

df_art.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation","abfss://silver@arslanstoragazure.dfs.core.windows.net/DimArtist/ Checkpoints")\
    .trigger(once=True)\
    .option("path","abfss://silver@arslanstoragazure.dfs.core.windows.net/DimArtist/data")\
    .toTable("spotifycata.silver.DimArtist")

# COMMAND ----------

# MAGIC %md
# MAGIC ### **DimTrack**

# COMMAND ----------

df_track=spark.readStream.format("cloudfiles")\
    .option("cloudfiles.format","parquet")\
    .option("cloudfiles.schemaLocation","abfss://silver@arslanstoragazure.dfs.core.windows.net/DimTrack/ Checkpoints")\
    .option("schemaEvolutionMode","rescue")\
    .load("abfss://bronze@arslanstoragazure.dfs.core.windows.net/DimTrack")

# COMMAND ----------

display(df_track)

# COMMAND ----------

df_track=df_track.withColumn("durationFlag",when(col('duration_sec')<150,"low")\
                             .when(col('duration_sec')<300,"medium")\
                             .otherwise("high"))
df_track=df_track.withColumn("track_name",regexp_replace(col("track_name"),'-',''))
display(df_track)

# COMMAND ----------

df_track=reusable().dropColumns(df_track,['_rescued_data'])
display(df_track)

# COMMAND ----------

df_track.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation","abfss://silver@arslanstoragazure.dfs.core.windows.net/DimTrack/ Checkpoints")\
    .trigger(once=True)\
    .option("path","abfss://silver@arslanstoragazure.dfs.core.windows.net/DimTrack/data")\
    .toTable("spotifycata.silver.DimTrack")

# COMMAND ----------

# MAGIC %md
# MAGIC ### **DimDate**

# COMMAND ----------

df_date=spark.readStream.format("cloudfiles")\
    .option("cloudfiles.format","parquet")\
    .option("cloudfiles.schemaLocation","abfss://silver@arslanstoragazure.dfs.core.windows.net/DimDate/ Checkpoints")\
    .option("schemaEvolutionMode","rescue")\
    .load("abfss://bronze@arslanstoragazure.dfs.core.windows.net/DimDate")

# COMMAND ----------

df_date=reusable().dropColumns(df_date,['_rescued_data'])
df_date.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation","abfss://silver@arslanstoragazure.dfs.core.windows.net/DimDate/ Checkpoints")\
    .trigger(once=True)\
    .option("path","abfss://silver@arslanstoragazure.dfs.core.windows.net/DimDate/data")\
    .toTable("spotifycata.silver.DimDate")

# COMMAND ----------

# MAGIC %md
# MAGIC ### **FactStream**

# COMMAND ----------

df_fact=spark.readStream.format("cloudfiles")\
  .option("cloudfiles.format","parquet")\
  .option("cloudfiles.schemaLocation","abfss://silver@arslanstoragazure.dfs.core.windows.net/FactStream/         Checkpoints")\
  .option("cloudfiles.schemaEvolutionMode","rescue")\
  .load("abfss://bronze@arslanstoragazure.dfs.core.windows.net/FactStream")

# COMMAND ----------

from utils.transformation import reusable

df_fact=reusable().dropColumns(df_fact,['_rescued_data'])
df_fact.writeStream.format("delta") \
    .outputMode("append") \
    .option("checkpointLocation", "abfss://silver@arslanstoragazure.dfs.core.windows.net/FactStream/Checkpoints") \
    .trigger(once=True) \
    .option("path", "abfss://silver@arslanstoragazure.dfs.core.windows.net/FactStream/data") \
    .toTable('spotifycata.silver.FactStream')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from spotifycata.gold.dimtrack
# MAGIC where track_id in (46,5)
# MAGIC
# MAGIC --Here are the DataFrames in the session: