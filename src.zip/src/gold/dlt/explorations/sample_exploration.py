# Databricks notebook source
# MAGIC %sql
# MAGIC select * from spotifycata.gold.dimuser